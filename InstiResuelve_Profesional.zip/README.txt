INSTIRESUELVE · IES EL PUIG
=============================
Esta versión está maquetada desde cero para evitar solapamientos.
Incluye:
- Login de acceso con correo @edu.gva.es.
- Recuperación de contraseña en la interfaz.
- Panel separado para Inicio, Nueva incidencia, Mis incidencias, Avisos y Ayuda.
- Diseño responsive para ordenador, tablet y móvil.
- Incidencias, filtros, prioridades y estados.
- Demo local para poder probarla inmediatamente.

IMPORTANTE:
El login de esta carpeta es una DEMO local. Para cuentas reales @edu.gva.es y recuperación real por correo hay que conectar un proveedor de autenticación y una base de datos del centro (por ejemplo Supabase) y configurar sus credenciales. No se deben inventar ni compartir claves privadas.
